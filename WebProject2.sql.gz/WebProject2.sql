-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 24, 2015 at 02:18 PM
-- Server version: 10.0.20-MariaDB-log
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `WebProject2`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE IF NOT EXISTS `answer` (
  `aid` int(11) NOT NULL,
  `answerer` tinytext NOT NULL,
  `time` tinytext NOT NULL,
  `answer_qid` int(11) NOT NULL,
  `content` text NOT NULL,
  `comments` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`aid`, `answerer`, `time`, `answer_qid`, `content`, `comments`) VALUES
(40, 'bb', '2015-06-21 14:07:58', 11, 'q 1 a 1 chinese test 中文测试', '[["bb", "q 1 a 1 c 1 chinese test \\u4e2d\\u6587\\u6d4b\\u8bd5", "2015-06-21 14:08:30"]]'),
(41, 'bb', '2015-06-21 14:11:11', 11, 'q 1 a 2 chinese test 中文测试', '[]'),
(42, 'aa', '2015-06-21 20:44:29', 12, 'khkjh', '[]'),
(43, 'aa', '2015-06-21 21:36:38', 12, '<img src=''/static/img/c39c089b6dbe47531e53d7839476073b_s.jpg''></img>', '[]'),
(44, 'aa', '2015-06-21 21:40:57', 12, '<img src=''/static/img/ccd0c0bd068c912e117040f1a8c5eabb_s.jpg''></img>', '[]'),
(45, 'aa', '2015-06-21 21:45:51', 12, '<img src=''/static/img/c39c089b6dbe47531e53d7839476073b_s.jpg''></img>', '[]'),
(46, 'aa', '2015-06-21 21:45:59', 12, '<img src=''/static/img/93271d07e417a8dee4c93cd172441090_b.jpg''></img>', '[]'),
(47, 'aa', '2015-06-21 21:46:13', 12, '<img src=''/static/img/5b4bcbed5fc8d1c749eeed044e2cd4ba_b.jpg''></img>', '[]'),
(48, 'aa', '2015-06-21 21:47:06', 12, '<img src=''/static/img/ccd0c0bd068c912e117040f1a8c5eabb_s.jpg''></img>', '[]'),
(49, 'qq', '2015-06-22 17:00:22', 14, 'asd', '[]'),
(50, 'aa', '2015-06-22 17:31:40', 11, 'q 1 a 3 chinese test 中文测试', '[]'),
(51, 'aa', '2015-06-22 21:48:36', 14, 'aa ans<img src=''/static/upload/469bb7186b0efd7e51a2f3bfc45bcb72_b.jpg''></img>', '[]'),
(52, 'aa', '2015-06-22 21:52:12', 14, '<img src=''/static/upload/4d96017c5dc41979dea6b8c9d54c5192_b.jpg''></img>', '[]'),
(53, 'aa', '2015-06-22 21:52:16', 14, '', '[]'),
(54, 'aa', '2015-06-22 21:55:44', 14, 'ans empty resolved', '[]'),
(55, 'cc', '2015-06-23 18:47:06', 16, 'ans from cc to q 5', '[]'),
(56, 'cc', '2015-06-23 18:52:32', 17, 'ans 1 from cc', '[["cc", "comment 1 to ans 1 from cc", "2015-06-23 18:54:13"]]'),
(57, 'cc', '2015-06-23 18:53:07', 17, 'ans 2 with pic from cc<img src=''/static/upload/65976372201207272033223352342377196_005.jpg''></img>', '[]'),
(58, 'bb', '2015-06-24 15:36:24', 18, 'ans from bb 中文 6-24-1535<img src=''/static/upload/12.jpg''></img>', '[]'),
(59, 'bb', '2015-06-24 15:37:22', 18, ' ', '[["bb", "\\u8bc4\\u8bba", "2015-06-24 15:38:06"]]'),
(60, 'aa', '2015-06-24 22:06:03', 19, '1', '[]'),
(61, 'aa', '2015-06-24 22:06:04', 19, '2', '[]'),
(62, 'aa', '2015-06-24 22:06:05', 19, '3', '[]'),
(63, 'aa', '2015-06-24 22:06:07', 19, '4', '[]'),
(64, 'aa', '2015-06-24 22:06:08', 19, '5', '[]'),
(65, 'aa', '2015-06-24 22:06:10', 19, '6', '[]'),
(66, 'aa', '2015-06-24 22:06:12', 19, '7', '[]'),
(67, 'aa', '2015-06-24 22:06:14', 19, '8', '[]'),
(68, 'aa', '2015-06-24 22:06:16', 19, '9', '[]'),
(69, 'aa', '2015-06-24 22:06:19', 19, '10', '[]'),
(70, 'aa', '2015-06-24 22:06:21', 19, '11', '[]'),
(71, 'aa', '2015-06-24 22:06:23', 19, '12', '[]'),
(72, 'aa', '2015-06-24 22:06:26', 19, '13', '[]'),
(73, 'aa', '2015-06-24 22:06:28', 19, '14', '[]'),
(74, 'aa', '2015-06-24 22:06:30', 19, '15', '[]'),
(75, 'aa', '2015-06-24 22:06:32', 19, '16', '[]'),
(76, 'aa', '2015-06-24 22:06:34', 19, '17', '[]');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `mid` int(11) NOT NULL,
  `from_uid` int(11) NOT NULL,
  `to_uid` int(11) NOT NULL,
  `msg` text NOT NULL,
  `time` tinytext NOT NULL,
  `checked` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`mid`, `from_uid`, `to_uid`, `msg`, `time`, `checked`) VALUES
(1, 10, 11, '10 to 11 msg', '2015-06-23 15:17:32', 1),
(2, 12, 10, '12 to 10 msg', '2015-06-23 15:17:35', 1),
(3, 10, 12, '10 to 12 msg', '2015-06-23 15:17:47', 0),
(4, 10, 12, 'test send', '2015-06-23 17:57:16', 0),
(8, 10, 12, 'test send 2', '2015-06-23 18:04:22', 0),
(9, 10, 14, 'from aa to test', '2015-06-23 18:05:18', 0),
(10, 10, 11, 'from bb to aa', '2015-06-23 18:14:12', 1),
(11, 10, 14, '中文测试 chinese test', '2015-06-23 18:19:50', 0),
(12, 15, 11, 'msg 1 from cc to bb', '2015-06-23 18:55:11', 1),
(13, 10, 11, 'from aa to bb', '2015-06-23 20:16:17', 1),
(14, 15, 10, 'from cc to aa', '2015-06-23 20:20:25', 1),
(15, 11, 10, 'from bb to aa', '2015-06-23 20:21:37', 1),
(16, 11, 15, 'from bb to cc', '2015-06-23 20:21:49', 1),
(17, 11, 12, 'from bb to qq', '2015-06-23 20:22:02', 0),
(18, 15, 10, 'from cc to aa', '2015-06-23 20:22:58', 1),
(19, 11, 10, 'from bb to aa 中文', '2015-06-24 15:44:30', 1);

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE IF NOT EXISTS `question` (
  `qid` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `ask_user` tinytext NOT NULL,
  `time` tinytext NOT NULL,
  `active_time` tinytext NOT NULL,
  `answers` text NOT NULL,
  `answers_n` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`qid`, `title`, `content`, `ask_user`, `time`, `active_time`, `answers`, `answers_n`) VALUES
(11, 'q 1 chinese test 中文测试', 'q 1 d chinese test 中文测试', 'bb', '2015-06-21 14:07:37', '2015-06-22 17:31:40', '[40, 41, 50]', 3),
(12, 'q 2', '', 'bb', '2015-06-21 14:39:00', '2015-06-21 21:47:06', '[42, 43, 44, 45, 46, 47, 48]', 7),
(13, 'q 3', '', 'aa', '2015-06-22 01:10:33', '2015-06-22 01:10:33', '[]', 0),
(14, 'asd', '', 'qq', '2015-06-22 17:00:19', '2015-06-22 21:55:44', '[49, 51, 52, 53, 54]', 5),
(15, 'q 4 from test', '', 'test', '2015-06-23 13:21:16', '2015-06-23 13:21:16', '[]', 0),
(16, 'q 5 from bb', '', 'bb', '2015-06-23 13:21:56', '2015-06-23 18:47:06', '[55]', 1),
(17, 'q 6 from cc', '', 'cc', '2015-06-23 18:52:07', '2015-06-23 18:53:07', '[56, 57]', 2),
(18, 'q from bb 中文 6-24-1535', '说得好iahisd''asgh', 'bb', '2015-06-24 15:35:38', '2015-06-24 15:37:22', '[58, 59]', 2),
(19, 'q ans show more test', '', 'aa', '2015-06-24 22:04:22', '2015-06-24 22:06:34', '[60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76]', 17);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `uid` int(11) NOT NULL,
  `username` tinytext NOT NULL,
  `email` tinytext NOT NULL,
  `password` tinytext NOT NULL,
  `avatar` tinytext NOT NULL,
  `motto` text NOT NULL,
  `questions` text NOT NULL,
  `questions_n` int(11) NOT NULL,
  `answers` text NOT NULL,
  `answers_n` int(11) NOT NULL,
  `following` text NOT NULL,
  `following_n` int(11) NOT NULL,
  `followed` text NOT NULL,
  `followed_n` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `username`, `email`, `password`, `avatar`, `motto`, `questions`, `questions_n`, `answers`, `answers_n`, `following`, `following_n`, `followed`, `followed_n`) VALUES
(10, 'aa', 'aa@aa.aa', 'a123456', 'aa.avatar?1435131931', 'motto aa 中文', '[13, 19]', 2, '[42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76]', 29, '[12]', 1, '[12]', 1),
(11, 'bb', 'bb@bb.bb', 'a123456', 'bb.avatar?1435036927', 'motto bb', '[11, 12, 16, 18]', 4, '[40, 41, 58, 59]', 4, '[12]', 1, '[12]', 1),
(12, 'qq', 'qq@qq.qq', 'a123456', 'qq.avatar?1435036958', 'motto qq', '[14]', 1, '[49]', 1, '[10, 11]', 2, '[11, 10, 15]', 3),
(14, 'test', 'test@aa.aa', 'a123456', 'test.avatar?1435036779', 'motto of test', '[15]', 1, '[]', 0, '[]', 0, '[]', 0),
(15, 'cc', 'cc@cc.cc', 'a123456', 'cc.avatar?1435062249', '', '[17]', 1, '[55, 56, 57]', 3, '[12]', 1, '[]', 0),
(16, 'dd', 'dd@aa.aa', 'a123456', 'head-default.jpg', '', '[]', 0, '[]', 0, '[]', 0, '[]', 0),
(17, 'ee', 'ee@aa.aa', 'a123456', 'head-default.jpg', '', '[]', 0, '[]', 0, '[]', 0, '[]', 0),
(18, 'ff', 'ff@aa.aa', 'a123456', 'head-default.jpg', '', '[]', 0, '[]', 0, '[]', 0, '[]', 0),
(19, 'gg', 'gg@aa.aa', 'a123456', 'head-default.jpg', '', '[]', 0, '[]', 0, '[]', 0, '[]', 0),
(20, 'hh', 'hh@aa.aa', 'a123456', 'head-default.jpg', '', '[]', 0, '[]', 0, '[]', 0, '[]', 0),
(21, 'ii', 'ii@aa.aa', 'a123456', 'head-default.jpg', '', '[]', 0, '[]', 0, '[]', 0, '[]', 0),
(22, 'jj', 'jj@aa.aa', 'a123456', 'head-default.jpg', '', '[]', 0, '[]', 0, '[]', 0, '[]', 0),
(23, 'kk', 'kk@kk.kk', 'a123456', 'head-default.jpg', '', '[]', 0, '[]', 0, '[]', 0, '[]', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answer`
--
ALTER TABLE `answer`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`qid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answer`
--
ALTER TABLE `answer`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `qid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
